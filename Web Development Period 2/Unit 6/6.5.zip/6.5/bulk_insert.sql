INSERT INTO characters 
(c_id, c_name, c_wit, c_strength, c_attack, c_defense, c_magic)
VALUES
(0, "Archibald", 0, 7, 2, 1, 0);


INSERT INTO characters 
(c_id, c_name, c_wit, c_strength, c_attack, c_defense, c_magic)
VALUES
(1, "Henrik", 4, 3, 3, 1, 2),
(2, "Isadore", 2, 6, 4, 0, 4),
(3, "Lucinda", 4, 3, 1, 8, 1),
(4, "Dominic", 5, 2, 3, 3, 2);